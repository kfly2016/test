#include "msg.h"
#include "iic.h"
#include "sensor.h"

void sensor_read(pSensor_data psensor_data)
{
	u8 i = 0;
	u16 x = 1, y = 1 ,z = 1;
	
	for(; i < 10; i++ )
	{
		MPU_IIC_Read_Byte(1);
		psensor_data->x = x*i;
		psensor_data->y = (y*i)+y;
		psensor_data->z = (z*i)-2;	
  }	
	
}

void sensor_read2(void)
{
	u8 i = 0;
	u16 x = 1, y = 1 ,z = 1;
	
	for(; i < 10; i++ )
	{
		//MPU_IIC_Read_Byte(1);
		
  }	
	
}