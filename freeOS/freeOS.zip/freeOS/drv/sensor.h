#ifndef __SENSOR_H
#define __SENSOR_H

#include "config.h"


typedef struct
{
	volatile uint16 x;
	volatile uint16 y;
	volatile uint16 z;
}Sensor_data, *pSensor_data;


void sensor_read(pSensor_data psensor_data);
void sensor_read2(void);
#endif