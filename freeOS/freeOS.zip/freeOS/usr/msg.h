#ifndef __MSG_H
#define __MSG_H

#include "config.h"
#include "sensor.h"

/*
  ��Ϣ����ṹ��
*/


#define BUFFER_SIZE   128

enum MSG_TYPE
{
	MSG_KEY,
	MSG_UART,
	MSG_SENSOR,
};


typedef struct
{
  uint8  buffer[BUFFER_SIZE];  
	uint16 len;
	uint8  opt;
}Buf;


typedef struct 
{
	uint8 msg_type;
	Buf   buf;
	Sensor_data sensor_data;
}Msg;



#define UART_HEADER1 0xAA
#define UART_HEADER2 0xAF


#endif