//FreeRTOS TEST

#include <stdio.h>
#include "config.h"
#include "bsp.h"
#include "uart.h"
#include "key.h"
#include "msg.h"
#include "led.h"
#include "sensor.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "list.h"
#include "portable.h"
#include "freertosconfig.h"


static const char *pTask1Str = "Task 1 is running \r\n";
static const char *pTask2Str = "Task 2 is running \r\n";
static unsigned long idleCnt = 0;
xQueueHandle xQueue, xQueue_send;
Msg msg_recv, msg_send; //��Ϣ���ջ���

/********************************************************************
�������ܣ���ӡͷ��Ϣ
��ڲ�������
��    �أ���
��    ע��
********************************************************************/
void print_headinfo(void)
{
	  printf("****begin to test*******\r\n");
}

void key_proc(uint8 *pbuf)
{
	printf( "key_proc = ");
	while(*pbuf!=NULL)
	{
		printf("%c",*pbuf);
		pbuf++;
	}
  printf( "\r\n");
}

void uart_proc(uint8 *pbuf)
{
	printf( "uart_proc = ");
	while(*pbuf!=NULL)
	{
		printf("%c",*pbuf);
		pbuf++;
	}	
	printf( "\r\n");
}

void sensor_proc(pSensor_data psensor)
{
	printf( "sensor_proc = ");
	printf("%d", psensor->x);
	printf("%d", psensor->y);
	printf("%d", psensor->z);
	printf( "\r\n");
	
}

/*
��������
*/
void vTask1( void *pvParameters )  
{  
  char *str = NULL;
	portBASE_TYPE xStatus;
  str = (char *) pvParameters;
	
	for( ;; )  
  {  
    if( uxQueueMessagesWaiting( xQueue ) != 0 )
    {
      printf( "Queue should have been empty!\r\n" );
    }
		
		xStatus = xQueueReceive( xQueue, &msg_recv, 500);
	  if( xStatus == pdPASS )
    {
			switch(msg_recv.msg_type)
			{
				case MSG_KEY:   { key_proc(msg_recv.buf.buffer) ;break;}
				case MSG_UART:  { uart_proc(msg_recv.buf.buffer);break;}
				case MSG_SENSOR:{ sensor_proc(&msg_recv.sensor_data);break;}
				default:break;
			} 			
    }
    else
		{
			//printf( "1s going !..Could not receive from the queue.\r\n" );
    } 
  }

} 

/*
  ��������
*/
void vTask2( void *pvParameters )  
{  
  char *str = "key is 1 ...\r\n";
	uint8 key_tmp;
	Msg key_msg;
	
	for( ;; )  
  {  
	 key_tmp = key_scan(0);
	 if(key_tmp)
	 {
		 key_msg.msg_type = MSG_KEY;
		 key_msg.buf.buffer[0] = '1';
		 xQueueSendToBack( xQueue, &key_msg, 0 );//�������·��͵�����
	 }
	 
	 vTaskDelay( 10/portTICK_RATE_MS );
  }  
} 

/*
	led����
*/
void vTask3( void *pvParameters ) 
{
	for( ;; )
	{
		LED1_OFF();
		LED2_ON();
		vTaskDelay( 300/portTICK_RATE_MS );	 
		LED1_ON();
		LED2_OFF();
		vTaskDelay( 300/portTICK_RATE_MS );	
	}
	  
}


/*
	sensor����
*/


void vTask4( void *pvParameters ) 
{
	Sensor_data sensor_data;
	Msg sensor_msg;
	
	for( ;; )
	{
		sensor_read(&sensor_data);
		sensor_msg.msg_type = MSG_SENSOR;
		sensor_msg.sensor_data = sensor_data;
		xQueueSendToBack( xQueue, &sensor_msg, 0 );//sensor������
		vTaskDelay( 1/portTICK_RATE_MS );	
	}
}

//���й��Ӻ���


void vApplicationIdleHook(void)
{
	idleCnt++;
}


/********************************************************************
�������ܣ�������
��ڲ�������
��    �أ�0��
��    ע��
********************************************************************/


int main(void)
{
		//init_devices();	 //��ʼ��Ӳ������
	 DAC_Ch1_SineWaveConfig();
	 //pwm_loop();
	 
}




/*
int main(void)
{
   	init_devices();	 //��ʼ��Ӳ������

	  print_headinfo();//��ӡͷ����Ϣ
	
	  xQueue      = xQueueCreate( 5, sizeof(msg_recv)); //����5������
	  xQueue_send = xQueueCreate( 5, sizeof(msg_send)); //����5������

    xTaskCreate( vTask1, "main_process",    configMINIMAL_STACK_SIZE, (void *)pTask1Str, tskIDLE_PRIORITY+4, NULL );
    xTaskCreate( vTask2, "key_process",     configMINIMAL_STACK_SIZE, (void *)pTask2Str, tskIDLE_PRIORITY+2, NULL );  
    xTaskCreate( vTask3, "led_process",     configMINIMAL_STACK_SIZE, (void *)pTask2Str, tskIDLE_PRIORITY+1, NULL );  
	  xTaskCreate( vTask4, "sensor_process",  configMINIMAL_STACK_SIZE, (void *)pTask2Str, tskIDLE_PRIORITY+3, NULL );  
	  
	
	  vTaskStartScheduler();  
	
	  while (1){}

    return 0; 
}

*/