#include "config.h"
#include "key.h"
#include <STM32F10X_GPIO.h>
#include "FreeRTOS.h"
#include "queue.h"

//PE3 PORT
void key_init(void) 
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);//??PORTA,PORTE??

	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3;//PE3
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //��������
 	GPIO_Init(GPIOE, &GPIO_InitStructure);
}


uint8 key_scan(uint8 mode)
{	 
	static u8 key_up = 1;//�����ɿ����
	
	if(mode)
	{
		key_up = 1;  //֧������
  }
	
	//if(key_up && (KEY0==0||KEY1==0||KEY2==0||WK_UP==1))
	if(key_up && KEY1==0)
	{
		vTaskDelay( 10/portTICK_RATE_MS );
		key_up=0;
		if(KEY1==0)
			return KEY1_PRES;
	  /*
		else if(KEY1==0)return KEY1_PRES;
		else if(KEY2==0)return KEY2_PRES;
		else if(WK_UP==1)return WKUP_PRES;
		*/
	}
	//else if(KEY0==1&&KEY1==1&&KEY2==1&&WK_UP==0)
	else if(KEY1==1)
	{
		key_up = 1;
	}	
 	
	return 0;// ?????
}