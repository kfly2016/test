#ifndef __UART_H
#define __UART_H

#include "config.h"



//#define RX_BUFFER_SIZE   128
//#define TX_BUFFER_SIZE   10

#define END_CODE1 0x0d
#define END_CODE2 0x0a
/*

typedef struct 
{
  uint8 _rx_buffer[RX_BUFFER_SIZE];
	uint16 _rx_cnt;

}UartBuf;
*/
#endif
