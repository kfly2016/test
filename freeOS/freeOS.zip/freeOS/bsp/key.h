#ifndef __KEY_H
#define __KEY_H

#include "config.h"

//#define KEY0  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)//????0
#define KEY1  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3)//????1
//#define KEY2  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_2)//????2 


 

//#define KEY0_PRES 	1	//KEY0??
#define KEY1_PRES	    2	//KEY1??
//#define KEY2_PRES	3	//KEY2??
//#define WKUP_PRES   4	//KEY_UP??(?WK_UP/KEY_UP)


void key_init(void);
uint8 key_scan(uint8);  					  

#endif