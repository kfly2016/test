  
#include "config.h"
#include "usart.h"	 
//uart reicer flag
#define b_uart_head  0x80
#define b_rx_over    0x40


// USART Receiver buffer
#define RX_BUFFER_SIZE   3
#define TX_BUFFER_SIZE   3


u8 U1TxBuffer[256];
u8 U1TxPackage[TX_BUFFER_SIZE];
u8 U1TxCounter=0;
u8 U1RxCounter=0;
u8 U1count=0; 
char TxPackFlag;//????????????

#pragma import(__use_no_semihosting)             
//??????????                 
struct __FILE 
{ 
	int handle; 
	/* Whatever you require here. If the only file you are using is */ 
	/* standard output using printf() for debugging, no file handling */ 
	/* is required. */ 
}; 
/* FILE is typedef� d in stdio.h. */ 
FILE __stdout;       
//??_sys_exit()??????????    
_sys_exit(int x) 
{ 
	x = x; 
} 
//???fputc?? 
int fputc(int ch, FILE *f)
{      
	while((UART4->SR&0X40)==0);//????,??????   
	UART4->DR = (u8) ch;      
	return ch;
}

 


//��ʼ��IO ����1 
//bound:������
void uart_init(u32 bound)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
 
  RCC_APB1PeriphClockCmd( RCC_APB1Periph_UART4 , ENABLE);	 		//ʹ�ܴ���4ʱ��
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC  , ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;	         		 		//USART1 TX
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;    		 		//�����������
  GPIO_Init(GPIOC, &GPIO_InitStructure);		    		 		//A�˿� 

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;	         	 		//USART1 RX
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   	 		//���ÿ�©����
  GPIO_Init(GPIOC, &GPIO_InitStructure);		         	 		//A�˿� 

   //Usart1 NVIC ����
 
  NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���

  USART_InitStructure.USART_BaudRate = 115200;						//����115200bps
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;		//����λ8λ
  USART_InitStructure.USART_StopBits = USART_StopBits_1;			//ֹͣλ1λ
  USART_InitStructure.USART_Parity = USART_Parity_No;				//��У��λ
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;   //��Ӳ������
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;					//�շ�ģʽ

  /* Configure USART1 */
  USART_Init(UART4, &USART_InitStructure);							//���ô��ڲ�������   
   /* Enable the USART1 */

  //USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
//	USART_ITConfig(UART4, USART_IT_TXE, ENABLE);

  USART_Cmd(UART4, ENABLE);	

}


/**************************????********************************************
*????:		void UART1_Put_Char(unsigned char DataToSend)
*?  ?:		RS232??????
????:
		unsigned char DataToSend   ????????
????:??	
*******************************************************************************/
void UART1_Put_Char(unsigned char DataToSend)
{
	U1TxBuffer[U1count++] = DataToSend;  
  USART_ITConfig(UART4, USART_IT_TXE, ENABLE);  
}
/**************************????********************************************
*????:		u8 UART1_Get_Char(void)
*?  ?:		RS232??????  ????,??UART1???????????
????:		 ??
????:     UART1??????	
*******************************************************************************/
u8 UART1_Get_Char(void)
{
	while (!(UART4->SR & USART_FLAG_RXNE));
	return(USART_ReceiveData(UART4));
}

/**************************????********************************************
*????:		void UART2_Put_String(unsigned char *Str)
*?  ?:		RS232?????
????:
		unsigned char *Str   ???????
????:??	
*******************************************************************************/
void UART1_Put_String(unsigned char *Str)
{
	//??Str?????????.
	while(*Str){
	if(*Str=='\r')
		UART1_Put_Char(0x0d);
		else if(*Str=='\n')
			UART1_Put_Char(0x0a);
			else 
				UART1_Put_Char(*Str);
	
	Str++;
	}

}


unsigned char rx_buffer[RX_BUFFER_SIZE];

//------------------------------------------------------
void USART1_IRQHandler(void)
{
  
  if(USART_GetITStatus(UART4, USART_IT_TXE) != RESET)
  {   
    USART_SendData(UART4, U1TxBuffer[U1TxCounter++]);
    USART_ClearITPendingBit(UART4, USART_IT_TXE);  
    if(U1TxCounter == U1count){USART_ITConfig(UART4, USART_IT_TXE, DISABLE);}
  }

  else if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
  {
  rx_buffer[U1RxCounter++]=USART_ReceiveData(UART4);
  if(U1RxCounter==RX_BUFFER_SIZE)
  {
  U1RxCounter=0;
  USART_ClearITPendingBit(UART4, USART_IT_RXNE);
  }
  }
}



  /*
void USART1_IRQHandler(void)                	//����1�жϷ������
{
	u8 Res;
	 	
	OSIntEnter();    

	if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
	{
		Res =USART_ReceiveData(UART4);//(USART1->DR);	//��ȡ���յ�������
		
		if((USART_RX_STA&0x8000)==0)//����δ���
		{
			if(USART_RX_STA&0x4000)//���յ���0x0d
			{
				if(Res!=0x0a)
				  USART_RX_STA=0;//���մ���,���¿�ʼ
				else 
				  USART_RX_STA|=0x8000;	//��������� 
			}
			else //��û�յ�0X0D
			{	
				if(Res==0x0d)
				    USART_RX_STA|=0x4000;
				else
				{
					USART_RX_BUF[USART_RX_STA&0X3FFF]=Res ;
					USART_RX_STA++;
					if(USART_RX_STA>(USART_REC_LEN-1))USART_RX_STA=0;//�������ݴ���,���¿�ʼ����	  
				}		 
			 }
		}   		 
     } 
	 
	OSIntExit();  											 

} 
*/


