#ifndef __USART_H
#define __USART_H

#include "stdio.h"	
#include <STM32F10X_USART.h>

void uart_init(u32 bound);
#endif


