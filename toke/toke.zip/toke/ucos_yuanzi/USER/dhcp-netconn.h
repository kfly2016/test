#ifndef __DHCP_NETCONN_H__
#define __DHCP_NETCONN_H__

void dhcp_netconn_init();

#endif /* __DHCP_NETCONN_H__ */
