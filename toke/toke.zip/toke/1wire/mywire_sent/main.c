#include "config.h"

#define BITS          32  // The number of bits in the command

#define HDR_MARK    1000  // The length of the Header:Mark
#define HDR_SPACE   2000  // The lenght of the Header:Space

#define BIT_MARK    3000  // The length of a Bit:Mark
#define ONE_SPACE   4000  // The length of a Bit:Space for 1's
#define ZERO_SPACE  5000  // The length of a Bit:Space for 0's

#define OTHER       1234  // Other things you may need to define

#define clockCyclesPerMicrosecond() ( 8000000L / 1000000L )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
// the prescaler is set so that timer0 ticks every 64 clock cycles, and the
// the overflow handler is called every 256 ticks.
#define MICROSECONDS_PER_TIMER0_OVERFLOW (clockCyclesToMicroseconds(64 * 256))

// the whole number of milliseconds per timer0 overflow
#define MILLIS_INC (MICROSECONDS_PER_TIMER0_OVERFLOW / 1000)

// the fractional number of milliseconds per timer0 overflow. we shift right
// by three to fit these numbers into a byte. (for the clock speeds we care
// about - 8 and 16 MHz - this doesn't lose precision.)
#define FRACT_INC ((MICROSECONDS_PER_TIMER0_OVERFLOW % 1000) >> 3)
#define FRACT_MAX (1000 >> 3)

/********************************************************************
�������ܣ���ʱx���뺯����
��ڲ�����x����ʱ�ĺ�������
��    �أ��ޡ�
��    ע���ޡ�
********************************************************************/
void delayms(uint16 k)                
{
    uint16 i,j;
		
    for(i=0;i<k;i++)
    {
       for(j=0;j<570;j++)
       ;
    }
}

void port_init(void)
{
 PORTE = 0x00;
 DDRE  = 0xff;
 PORTB = 0x00;
 DDRB  = 0x00;
 PORTC = 0x00; //m103 output only
 DDRC  = 0x00;
 PORTD = 0x00;
 DDRD  = 0x00;
}

volatile unsigned long timer0_overflow_count = 0;
volatile unsigned long timer0_millis = 0;
static unsigned char timer0_fract = 0;


unsigned long micros() 
{
   unsigned long m = 0;
   uint8 oldSREG = SREG, t = 0;
	
   CLI();
   m = timer0_overflow_count;
   
   t = TCNT0;
   
   if ((TIFR & BIT(TOV0)) && (t < 255))
		m++;
   
   SREG = oldSREG;
	
   return ((m << 8) + t) * (64 / clockCyclesPerMicrosecond());
} 

#pragma interrupt_handler timer0_ovf_isr:iv_TIM0_OVF
void timer0_ovf_isr(void)
{
 // copy these to local variables so they can be stored in registers
	// (volatile variables must be read from memory on every access)
  unsigned long m = timer0_millis;
  unsigned char f = timer0_fract;

	m += MILLIS_INC;
	f += FRACT_INC;
	if (f >= FRACT_MAX) {
		f -= FRACT_MAX;
		m += 1;
	}

	timer0_fract = f;
	timer0_millis = m;
	timer0_overflow_count++;
}



void time0_init()
{
 TCCR0 = 0x4b;
 TIMSK = BIT(TOIE0);
 /*
 TCCR0 = 0x00; //stop
 TCNT0 = 0x01; //set count
 OCR0  = 0xFF;  //set compare
 TCCR0 = 0x43; //start timer
 */
}

//call this routine to initialize all peripherals
void init_devices(void)
{
  CLI(); //disable all interrupts
 XDIV  = 0x00; //xtal divider
 XMCRA = 0x00; //external memory
 port_init();

 MCUCR = 0x00;
 EICRA = 0x00; //extended ext ints
 EICRB = 0x00; //extended ext ints
 EIMSK = 0x00;
 TIMSK = 0x00; //timer interrupt sources
 ETIMSK = 0x00; //extended timer interrupt sources
 SEI(); //re-enable interrupts
}

void sendRaw (const unsigned int buf[],  unsigned int len)
{
  unsigned int i = 0;
  
  for (i = 0;  i < len;  i++) {
		if (i & 1)  space(buf[i]) ;
		else        mark (buf[i]) ;
	}
}

void sendShuzu (unsigned long data,  int nbits)
{
	unsigned long  mask = 0 ;
	
	// Set IR carrier frequency
	//enableIROut(38);

	// Header
	mark (HDR_MARK);
	space(HDR_SPACE);

	// Data
	for (mask = 1UL << (nbits - 1);  mask;  mask >>= 1) {
		if (data & mask) {
			mark (BIT_MARK);
			space(ONE_SPACE);
		} else {
			mark (BIT_MARK);
			space(ZERO_SPACE);
		}
	}

	// Footer
	mark(BIT_MARK);
    space(0);  // Always end with the LED off
}

//
void main(void)
{
 const unsigned int buf_data[2] = {0x1234, 0x4321};
 //uint8 time = 1;
 init_devices();
 
 _NOP();
 //insert your functional code here...
 while(1)
 {
  delayms(100);
  sendShuzu(0x123, 12);
 }
  
}  