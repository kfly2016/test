//ICC-AVR application builder : 2016/3/18 10:46:16
// Target : M16
// Crystal: 8.0000Mhz

#include "config.h"
#include "decode.h"

extern irparams_t irparams;

#define BITS          32  // The number of bits in the command
#define HDR_MARK    1000  // The length of the Header:Mark
#define HDR_SPACE   2000  // The lenght of the Header:Space

#define BIT_MARK    3000  // The length of a Bit:Mark
#define ONE_SPACE   4000  // The length of a Bit:Space for 1's
#define ZERO_SPACE  5000  // The length of a Bit:Space for 0's

#define OTHER       1234  // Other things you may need to define

typedef struct  
{
		//decode_type_t          decode_type;  // UNKNOWN, NEC, SONY, RC5, ...
		unsigned int           address;      // Used by Panasonic & Sharp [16-bits]
		unsigned long          value;        // Decoded value [max 32-bits]
		int                    bits;         // Number of bits in decoded value
		volatile unsigned int  *rawbuf;      // Raw intervals in 50uS ticks
		int                    rawlen;       // Number of records in rawbuf
		int                    overflow;     // true iff IR raw code too long
}decode_results;


decode_results results;

int decodeShuzu (decode_results *results)
{
	unsigned long  data   = 0;  // Somewhere to build our code
	int            offset = 1;  // Skip the Gap reading
	int i = 0;

	// Check we have the right amount of data
	if (irparams.rawlen != 1 + 2 + (2 * BITS) + 1)  return false ;

	// Check initial Mark+Space match
	if (!MATCH_MARK (results->rawbuf[offset++], HDR_MARK ))  
	  return false ;
	if (!MATCH_SPACE(results->rawbuf[offset++], HDR_SPACE))  
	  return false ;

	// Read the bits in
	for (i = 0;  i < 32;  i++) {
		// Each bit looks like: MARK + SPACE_1 -> 1
		//                 or : MARK + SPACE_0 -> 0
		if (!MATCH_MARK(results->rawbuf[offset++], BIT_MARK))  return false ;

		// IR data is big-endian, so we shuffle it in from the right:
		if      (MATCH_SPACE(results->rawbuf[offset], ONE_SPACE))   data = (data << 1) | 1 ;
		else if (MATCH_SPACE(results->rawbuf[offset], ZERO_SPACE))  data = (data << 1) | 0 ;
		else                                                        return false ;
		offset++;
	}

	// Success
	results->bits        = BITS;
	results->value       = data;
	//results->decode_type = SHUZU;
	return true;
}

int decode(decode_results *results)
{
 results->rawbuf   = irparams.rawbuf;
 results->rawlen   = irparams.rawlen;
 results->overflow = irparams.overflow;
 
 if (irparams.rcvstate != STATE_STOP)  
    return false ;
	
 if (decodeShuzu(results))  
    return true ;
	
 // decodeHash returns a hash on any input.
 // Thus, it needs to be last in the list.
 // If you add any decodes, add them before this.
 //if (decodeHash(results))  
   //  return true ;

	// Throw away and start over
	resume();
	return false;
 }


void port_init(void)
{
 PORTA = 0x00;
 DDRA  = 0x00;
 PORTB = 0x00;
 DDRB  = 0x00;
 PORTC = 0x00; //m103 output only
 DDRC  = 0x0F;
 PORTD = 0x0f;
 DDRD  = 0x00;
}

//call this routine to initialize all peripherals
void init_devices(void)
{
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 port_init();
 timer0_init();

 MCUCR = 0x00;
 GICR  = 0x00;
 TIMSK = 0x01; //timer interrupt sources
 SEI(); //re-enable interrupts
 //all peripherals are now initialized
}


void main()
{
  init_devices();
  
  while(1){
  if (decode(&results)) 
  {
//    Serial.println(results.value, HEX);
//    dump(&results);
    resume(); // Receive the next value
  }
  }
}