#ifndef __CONFIG_H__
#define __CONFIG_H__


#define uint8    unsigned char
#define uint16   unsigned short int
#define uint32   unsigned long int
#define int8     signed char
#define int16    signed short int
#define int32    signed long int
#define uint64   unsigned long long int
#define int64    signed long long int


#define false 	 0  
#define true  	 1

/********************************/
/*     Ӧ�ó�������             */
/*Application Program Configurations*/
/********************************/
//���¸�����Ҫ�Ķ�
//This segment could be modified as needed.

#include <iom16v.h>
#include <macros.h>
#include <RD_UseBITs.h>
#include <USE_BIT.h>


#endif