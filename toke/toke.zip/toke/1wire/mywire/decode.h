#ifndef __DECODE_H__
#define __DECODE_H__


#define RAWBUF  101  // Maximum length of raw duration buffer

// microseconds per clock interrupt tick
#define USECPERTICK    50
// Minimum gap between IR transmissions
#define _GAP            5000
#define GAP_TICKS       (_GAP/USECPERTICK)

// Due to sensor lag, when received, Marks  tend to be 100us too long and
//                                   Spaces tend to be 100us too short
#define MARK_EXCESS    100

// Upper and Lower percentage tolerances in measurements
#define TOLERANCE       25
#define LTOL            (1.0 - (TOLERANCE/100.))
#define UTOL            (1.0 + (TOLERANCE/100.))

#define TICKS_LOW(us)   ((int)(((us)*LTOL/USECPERTICK)))
#define TICKS_HIGH(us)  ((int)(((us)*UTOL/USECPERTICK + 1)))

// ISR State-Machine : Receiver States
#define STATE_IDLE      2
#define STATE_MARK      3
#define STATE_SPACE     4
#define STATE_STOP      5
#define STATE_OVERFLOW  6

// IR detector output is active low
#define MARK   0
#define SPACE  1


#define DATA_PORT PIND_1


typedef struct 
{
        // The fields are ordered to reduce memory over caused by struct-padding
		uint8       rcvstate;        // State Machine state
		uint8       recvpin;         // Pin connected to IR data from detector
		uint8       blinkpin;
		uint8       blinkflag;       // true -> enable blinking of pin on IR processing
		uint8       rawlen;          // counter of entries in rawbuf
		unsigned int  timer;           // State timer, counts 50uS ticks.
		unsigned int  rawbuf[RAWBUF];  // raw data
		uint8       overflow;        // Raw buffer overflow occurred
}irparams_t;


#endif