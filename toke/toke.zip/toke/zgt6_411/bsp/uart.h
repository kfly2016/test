#ifndef __UART1_H
#define __UART1_H

#include <stdio.h> 

void usart1_init(void);
int fgetc(FILE *f);
int fputc(int ch, FILE *f);

#endif
