#ifndef __BSP_C__
#define __BSP_C__

#include "stm32f10x.h"

void init_devices(void);
void delay_ms(uint16 nms);
void delay_us(u32 nus);

#endif
