/*



�ײ���Ҫ�Ľṹ��
����ӿڣ���·������ӿڹ�����page92
��ʼ��������������ֽڣ�  hwaddr_len, hwaddr[], mtu, flags
//ʵ��netif.c �� netif.h


struct netif {
  
  struct netif *next;	 /*���� */

  ip_addr_t ip_addr;	 //ip����
  ip_addr_t netmask;
  ip_addr_t gw;

  /** This function is called by the network device driver
   *  to pass a packet up the TCP/IP stack. */
  netif_input_fn input;
  /** This function is called by the IP module when it wants
   *  to send a packet on the interface. This function typically
   *  first resolves the hardware address, then sends the packet. */
  netif_output_fn output;
  /** This function is called by the ARP module when it wants
   *  to send a packet on the interface. This function outputs
   *  the pbuf as-is on the link medium. */
  netif_linkoutput_fn linkoutput;
#if LWIP_NETIF_STATUS_CALLBACK
  /** This function is called when the netif state is set to up or down
   */
  netif_status_callback_fn status_callback;
#endif /* LWIP_NETIF_STATUS_CALLBACK */
#if LWIP_NETIF_LINK_CALLBACK
  /** This function is called when the netif link is set to up or down
   */
  netif_status_callback_fn link_callback;
#endif /* LWIP_NETIF_LINK_CALLBACK */
#if LWIP_NETIF_REMOVE_CALLBACK
  /** This function is called when the netif has been removed */
  netif_status_callback_fn remove_callback;
#endif /* LWIP_NETIF_REMOVE_CALLBACK */
  /** This field can be set by the device driver and could point
   *  to state information for the device. */
  void *state;
#if LWIP_DHCP
  /** the DHCP client state information for this netif */
  struct dhcp *dhcp;
#endif /* LWIP_DHCP */
#if LWIP_AUTOIP
  /** the AutoIP client state information for this netif */
  struct autoip *autoip;
#endif
#if LWIP_NETIF_HOSTNAME
  /* the hostname for this netif, NULL is a valid value */
  char*  hostname;
#endif /* LWIP_NETIF_HOSTNAME */
  /** maximum transfer unit (in bytes) */
  u16_t mtu;
  /** number of bytes used in hwaddr */
  u8_t hwaddr_len;
  /** link level hardware address of this interface */
  u8_t hwaddr[NETIF_MAX_HWADDR_LEN];
  /** flags (see NETIF_FLAG_ above) */
  u8_t flags;
  /** descriptive abbreviation */
  char name[2];
  /** number of this interface */
  u8_t num;
#if LWIP_SNMP
  /** link type (from "snmp_ifType" enum from snmp.h) */
  u8_t link_type;
  /** (estimate) link speed */
  u32_t link_speed;
  /** timestamp at last change made (up/down) */
  u32_t ts;
  /** counters */
  u32_t ifinoctets;
  u32_t ifinucastpkts;
  u32_t ifinnucastpkts;
  u32_t ifindiscards;
  u32_t ifoutoctets;
  u32_t ifoutucastpkts;
  u32_t ifoutnucastpkts;
  u32_t ifoutdiscards;
#endif /* LWIP_SNMP */
#if LWIP_IGMP
  /** This function could be called to add or delete a entry in the multicast
      filter table of the ethernet MAC.*/
  netif_igmp_mac_filter_fn igmp_mac_filter;
#endif /* LWIP_IGMP */
#if LWIP_NETIF_HWADDRHINT
  u8_t *addr_hint;
#endif /* LWIP_NETIF_HWADDRHINT */
#if ENABLE_LOOPBACK
  /* List of packets to be queued for ourselves. */
  struct pbuf *loop_first;
  struct pbuf *loop_last;
#if LWIP_LOOPBACK_MAX_PBUFS
  u16_t loop_cnt_current;
#endif /* LWIP_LOOPBACK_MAX_PBUFS */
#endif /* ENABLE_LOOPBACK */
};


struct ethernetif {
  struct eth_addr *ethaddr;
  /* Add whatever per-interface state that is needed here. */
};

 /** Ethernet header */
struct eth_hdr {
#if ETH_PAD_SIZE
  PACK_STRUCT_FIELD(u8_t padding[ETH_PAD_SIZE]);
#endif
  PACK_STRUCT_FIELD(struct eth_addr dest);
  PACK_STRUCT_FIELD(struct eth_addr src);
  PACK_STRUCT_FIELD(u16_t type);
} PACK_STRUCT_STRUCT;

/*  	
	lwip ��ʼ��������

	void lwip_init_task(void)
    {
		struct ip_addr ipaddr, netmask, gw;
	
	    lwip_init(); //��ʼ��  ----------------------------->����init.c
		                                                        lwip_init(void)
																{
																  /* Modules initialization */
																  stats_init();
																#if !NO_SYS
																  sys_init();
																#endif /* !NO_SYS */
																  mem_init(); //�ڴ��ʼ��
																  memp_init();//pool�ڴ�س�ʼ�� page65
																  pbuf_init();
																  netif_init();
																#if LWIP_SOCKET
																  lwip_socket_init();
																#endif /* LWIP_SOCKET */
																  ip_init();
																#if LWIP_ARP
																  etharp_init();
																#endif /* LWIP_ARP */
																#if LWIP_RAW
																  raw_init();
																#endif /* LWIP_RAW */
																#if LWIP_UDP
																  udp_init();
																#endif /* LWIP_UDP */
																#if LWIP_TCP  --------------------->//��Щ�궨����opt.h
																  tcp_init();
																#endif /* LWIP_TCP */
																#if LWIP_SNMP
																  snmp_init();
																#endif /* LWIP_SNMP */
																#if LWIP_AUTOIP
																  autoip_init();
																#endif /* LWIP_AUTOIP */
																#if LWIP_IGMP
																  igmp_init();
																#endif /* LWIP_IGMP */
																#if LWIP_DNS
																  dns_init();
																#endif /* LWIP_DNS */
																
																#if LWIP_TIMERS
																  sys_timeouts_init();
																#endif /* LWIP_TIMERS */
																}
		IP4_ADDR(&gw, 192,168,1,1);	 //IP��ַת��������
		IP4_ADDR(&ipaddr, 192,168,1,37);
		IP4_ADDR(&netmask, 255,255,255,0);
	
	    netif_add(&enc28j60_netif, &ipaddr, &netmask, &gw, NULL, ethernetif_init,ethernet_input);-------------------------->
																															netif_add(struct netif *netif, ip_addr_t *ipaddr, ip_addr_t *netmask,
																															  ip_addr_t *gw, void *state, netif_init_fn init, netif_input_fn input)
																															{
																															
																															 ..........................
																															  /* remember netif specific state information data */
																															  netif->state = state;
																															  netif->num = netif_num++;
																															  netif->input = input;	    //�ѵײ����뺯�������ںˣ����ں˵��� ethernet_input
																															  ................
																															  netif_set_addr(netif, ipaddr, netmask, gw); //page109
																															
																															  /* call user specified initialization function for netif */
																															  if (init(netif) != ERR_OK) {	 //��ʼ���û����� ethernetif_init
																															    return NULL;
																															  }
																															
																															  /* add this netif to the list */
																															  netif->next = netif_list;
																															  netif_list = netif;
																															  snmp_inc_iflist();
																															
																															#if LWIP_IGMP
																															  /* start IGMP processing */
																															  if (netif->flags & NETIF_FLAG_IGMP) {
																															    igmp_start(netif);
																															  }
																															#endif /* LWIP_IGMP */
																															
																															  LWIP_DEBUGF(NETIF_DEBUG, ("netif: added interface %c%c IP addr ",
																															    netif->name[0], netif->name[1]));
																															  ip_addr_debug_print(NETIF_DEBUG, ipaddr);
																															  LWIP_DEBUGF(NETIF_DEBUG, (" netmask "));
																															  ip_addr_debug_print(NETIF_DEBUG, netmask);
																															  LWIP_DEBUGF(NETIF_DEBUG, (" gw "));
																															  ip_addr_debug_print(NETIF_DEBUG, gw);
																															  LWIP_DEBUGF(NETIF_DEBUG, ("\n"));
																															  return netif;
																															}
		netif_set_default(&enc28j60_netif);
		netif_set_up(&enc28j60_netif);
    }
	
	
	
	
	
	
	
	
	
	//��ѯ����
	while(1)
	{
		process_mac(); // ���ϵ��ý������ݺ����������ݰ�����
		sys_check_timeouts(); //LWIP��ʱ����
		
		//todo: add your own user code here
	}

	process_mac() -> 
	
	----ethernetif.c-----

	void process_mac(void)
    {
      s32_t ret = 0;
      do
      {
       ret = ethernetif_input(&enc28j60_netif);	->
      }while(ret);
    }

   	//arp�㺯������ȡ��̫�����ݣ���֡IP���ݽ�IP�� page98
   s32_t ethernetif_input(struct netif *netif)
   {
       	struct eth_hdr *ethhdr;
	   
	   ...............
	   p = low_level_input(netif); ------------------------>	    static struct pbuf *
																	low_level_input(struct netif *netif)
																	{
																	 return PacketReceive(netif);  ------------------------------->   static unsigned char  MyRecvbuf[1500]; 
																																		struct pbuf *PacketReceive(struct netif *netif)
																																		{
																																			struct pbuf *p = NULL;	
																																			unsigned int recvlen = 0;
																																			unsigned int i = 0;
																																			struct pbuf *q = NULL;
																																		    
																																			recvlen = enc28j60PacketReceive(1500, MyRecvbuf);
																																		
																																			if(!recvlen)	       //�������ݳ���Ϊ0��ֱ�ӷ��ؿ�
																																			{
																																			    return NULL;
																																			}
																																			
																																			//�����ں�pbuf�ռ䣬Ϊpbuf���������� RAM��ROM, REF,POOL����,�������RAM����	 //page83
																																			p = pbuf_alloc(PBUF_RAW, recvlen, PBUF_RAM);   //����PBUF_RAW �������Ĳ���һ������ page85
																																			
																																			if(!p)			       //����ʧ�ܣ��򷵻ؿ�
																																			{
																																			    LWIP_PLATFORM_DIAG(("PacketReceive: pbuf_alloc fail ,len=%"U32_F"\n\t", recvlen));
																																				return NULL;
																																			 }
																																		    //����ɹ����������ݵ�pbuf��
																																			q = p;
																																				
																																			while(q != NULL)
																																			{   
																																				memcpy(q->payload,&MyRecvbuf[i],q->len);
																																				i += q->len;
																																				q = q->next;
																																				if(i >= recvlen)  break;
																																			}
																																				
																																			return p;
																																		}
																	}

	  /* points to packet payload, which starts with an Ethernet header */
      ethhdr = p->payload;	//������ݰ��ײ���ַ page81

	  switch (htons(ethhdr->type)) {  //�������ݰ��ײ��ṩ�����ͽ��ں˽�һ������  page126
	  /* IP or ARP packet? */
	  case ETHTYPE_IP:
	  case ETHTYPE_ARP:
	
	  case ETHTYPE_PPPOEDISC:
	  case ETHTYPE_PPPOE:
	#endif /* PPPOE_SUPPORT */
	    /* full packet send to tcpip_thread to process */
	    if (netif->input(p, netif)!=ERR_OK)
	     { LWIP_DEBUGF(NETIF_DEBUG, ("ethernetif_input: IP input error\n"));
	       pbuf_free(p);
	       p = NULL;
     }
    break;


   }
*/


ʵ��1 PING:
PC���Ͳ�������������PINGͨ
PC���� 192.168.1.30
       255.255.255.0
       192.168.1.1
DNS :  192.168.1.1

PC ->ping 192.168.1.37 -> stm32  

���ڴ�ӡ��
etharp_timer
ethernet_input: dest:01:02:03:04:05:06, src:fc:aa:14:7f:ed:2c, type:800
icmp_input: ping
etharp_send_ip: sending packet 20000d90
ethernet_input: dest:01:02:03:04:05:06, src:fc:aa:14:7f:ed:2c, type:800
icmp_input: ping
etharp_send_ip: sending packet 20000d90
ethernet_input: dest:01:02:03:04:05:06, src:fc:aa:14:7f:ed:2c, type:800
icmp_input: ping
etharp_send_ip: sending packet 20000d90
etharp_timer
ethernet_input: dest:01:02:03:04:05:06, src:fc:aa:14:7f:ed:2c, type:800
icmp_input: ping
etharp_send_ip: sending packet 20000d90

CMD��ӡ��
���� Ping 192.168.1.37 ���� 32 �ֽڵ�����:
���� 192.168.1.37 �Ļظ�: �ֽ�=32 ʱ��=14ms TTL=255
���� 192.168.1.37 �Ļظ�: �ֽ�=32 ʱ��=14ms TTL=255
���� 192.168.1.37 �Ļظ�: �ֽ�=32 ʱ��=14ms TTL=255
���� 192.168.1.37 �Ļظ�: �ֽ�=32 ʱ��=14ms TTL=255

192.168.1.37 �� Ping ͳ����Ϣ:
    ���ݰ�: �ѷ��� = 4���ѽ��� = 4����ʧ = 0 (0% ��ʧ)��
�����г̵Ĺ���ʱ��(�Ժ���Ϊ��λ):
    ��� = 14ms��� = 14ms��ƽ�� = 14ms
    
C:\Users\SZMD>arp -a

�ӿ�: 192.168.1.30 --- 0xe
  Internet ��ַ         ������ַ              ����
  192.168.1.37          01-02-03-04-05-06     ��̬
  192.168.1.255         ff-ff-ff-ff-ff-ff     ��̬
  224.0.0.22            01-00-5e-00-00-16     ��̬
  224.0.0.251           01-00-5e-00-00-fb     ��̬
  224.0.0.252           01-00-5e-00-00-fc     ��̬
  239.255.255.250       01-00-5e-7f-ff-fa     ��̬
  
=======================================================================================
2 . ��̬�޸�IP��ַ page109

�� lwip_init_task ������ ��
  netif_add(&enc28j60_netif, &ipaddr, &netmask, &gw, NULL, ethernetif_init,ethernet_input);
     --->����netif_set_addr(netif, ipaddr, netmask, gw); //����IP
        --->void
								netif_set_addr(struct netif *netif, ip_addr_t *ipaddr, ip_addr_t *netmask,
								    ip_addr_t *gw)
								{
								  netif_set_ipaddr(netif, ipaddr);  //����������IP�Ⱥ���
								  netif_set_netmask(netif, netmask);
								  netif_set_gw(netif, gw);
								}
								
	һ��Ϊ �� �������� ������������
	
	