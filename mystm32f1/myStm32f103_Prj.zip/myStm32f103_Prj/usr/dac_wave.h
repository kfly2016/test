/*
*********************************************************************************************************
*
*	ģ������ : DAC�������
*	�ļ����� : dac_wave.h
*	��    �� : V1.0
*
*	Copyright (C), 20xx-20xx, xxx���� www.xxx.com
*
*********************************************************************************************************
*/

#ifndef __DAC_WAVE_H
#define __DAC_WAVE_H

#include "bsp.h"

#define DAC_DHR12RD_Address      0x40007420

#define DAC_DHR8R1_Address      0x40007410
#define DAC_DHR12R1_Address		  0x40007408

void dac_InitHard(uint32_t _BufAddr, uint32_t _Count, uint32_t _DacFreq);

void dac_SetSinWave(uint16_t _vpp, uint32_t _freq);
void dac_SetRectWave(uint16_t _low, uint16_t _high, uint32_t _freq, uint16_t _duty);
void dac_SetTriWave(uint16_t _low, uint16_t _high, uint32_t _freq, uint16_t _duty);
void dac_StopWave(void);

#endif
