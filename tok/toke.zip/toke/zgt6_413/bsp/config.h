#ifndef __CONFIG_H
#define __CONFIG_H

#define uint8    unsigned char
#define uint16   unsigned int
#define uint32   unsigned long int
#define int8     signed char
#define int16    signed short int
#define int32    signed long int
#define uint64   unsigned long long int
#define int64    signed long long int

/********************************/
/*     Ӧ�ó�������             */
/*Application Program Configurations*/
/********************************/
//���¸�����Ҫ�Ķ�
//This segment could be modified as needed.

//#include <stm32f10x_lib.h>

#define  USR_PRINT     //���Դ�ӡ����

#endif	
