#include "config.h"



//+=============================================================================
// Custom delay function that circumvents Arduino's delayMicroseconds limit


//+=============================================================================
// Sends an IR mark for the specified number of microseconds.
// The mark output is modulated at the PWM frequency.
//
void mark (unsigned int time)
{
//	TIMER_ENABLE_PWM; // Enable pin 3 PWM output
  PORTE_0 = 1;
	if (time > 0) 
	  custom_delay_usec(time);
}


//+=============================================================================
// Leave pin off for time (given in microseconds)
// Sends an IR space for the specified number of microseconds.
// A space is no output, so the PWM output is disabled.
//
void space (unsigned int time)
{
//	TIMER_DISABLE_PWM; // Disable pin 3 PWM output
  PORTE_0 = 0;
	if (time > 0) 
	 custom_delay_usec(time);
}

